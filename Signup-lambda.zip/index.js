const AWS = require("aws-sdk");
const { v4: uuidv4 } = require("uuid");

const dynamoDb = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = "JobAI_Users";

exports.handler = async (event) => {
    console.log("Event received:", event); // Log the event for debugging

    try {
        // Parse the event body
        const requestBody = JSON.parse(event.body);

        // Validate input data
        if (!requestBody.username || !requestBody.password || !requestBody.phone || !requestBody.email) {
            return {
                statusCode: 400,
                headers: {
                    "Access-Control-Allow-Origin": "*",
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ message: "Missing required fields" }),
            };
        }

        // Generate a UUID for the user
        const userId = uuidv4();

        // Create the user object
        const user = {
            UserID: userId,
            username: requestBody.username,
            passwd: requestBody.password,
            phone: requestBody.phone,
            email: requestBody.email,
        };

        console.log("User to insert:", user); // Log user data for debugging

        // Insert user into DynamoDB
        await dynamoDb
            .put({
                TableName: TABLE_NAME,
                Item: user,
            })
            .promise();

        console.log("User successfully added to DynamoDB");

        // Success response
        return {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Origin": "*", // Allow all origins
                "Access-Control-Allow-Credentials": true, // Allow credentials
                "Content-Type": "application/json", // Set content type
            },
            body: JSON.stringify({
                message: "User added successfully!",
                user: {
                    username: requestBody.username,
                    email: requestBody.email,
                },
            }),
        };
    } catch (error) {
        console.error("Error processing request:", error); // Log the error for debugging
        return {
            statusCode: 500,
            headers: {
                "Access-Control-Allow-Origin": "*", // Allow all origins on error response as well
                "Access-Control-Allow-Credentials": true,
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                message: "Failed to register user",
                error: error.message, // Provide error details for debugging
            }),
        };
    }
};
