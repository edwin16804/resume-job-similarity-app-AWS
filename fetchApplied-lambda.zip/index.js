const AWS = require("aws-sdk");
const dynamoDB = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = "AppliedJobs"; // Replace with your DynamoDB table name

exports.handler = async (event) => {
    try {
        const { email } = event.queryStringParameters || {};

        // Check if email is provided
        if (!email) {
            return {
                statusCode: 400,
                headers: {
                    "Access-Control-Allow-Origin": "*", // Allow all origins
                    "Access-Control-Allow-Headers": "Content-Type", // Allow necessary headers
                    "Access-Control-Allow-Methods": "GET,OPTIONS", // Allow GET and OPTIONS methods
                },
                body: JSON.stringify({ message: "Email is required." }),
            };
        }

        // Query DynamoDB to fetch all jobs applied by the given email
        const params = {
            TableName: TABLE_NAME,
            KeyConditionExpression: "email = :email", // Query by email
            ExpressionAttributeValues: {
                ":email": email,
            },
        };

        // Execute the query to fetch applied jobs
        const data = await dynamoDB.query(params).promise();

        // Return the results
        return {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Origin": "*", // Allow all origins
                "Access-Control-Allow-Headers": "Content-Type", // Allow necessary headers
                "Access-Control-Allow-Methods": "GET,OPTIONS", // Allow GET and OPTIONS methods
            },
            body: JSON.stringify(data.Items || []), // Return applied jobs or empty array if none
        };
    } catch (error) {
        console.error("Error fetching applied jobs:", error);
        return {
            statusCode: 500,
            headers: {
                "Access-Control-Allow-Origin": "*", // Allow all origins
                "Access-Control-Allow-Headers": "Content-Type", // Allow necessary headers
                "Access-Control-Allow-Methods": "GET,OPTIONS", // Allow GET and OPTIONS methods
            },
            body: JSON.stringify({ message: "Failed to fetch applied jobs." }),
        };
    }
};
