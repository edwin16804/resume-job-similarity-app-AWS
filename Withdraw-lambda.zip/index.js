const AWS = require("aws-sdk");
const dynamoDB = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = "AppliedJobs"; 

exports.handler = async (event) => {
    try {
      const { email } = event.queryStringParameters || {};

        if (!email) {
            return {
                statusCode: 400,
                headers: {
                    "Access-Control-Allow-Origin": "*", 
                    "Access-Control-Allow-Headers": "Content-Type",
                    "Access-Control-Allow-Methods": "DELETE, OPTIONS",
                },
                body: JSON.stringify({ message: "Email is required." }),
            };
        }

        const params = {
            TableName: TABLE_NAME,
            Key: {
                email: email,
            },
        };

        // Deleting all job applications for the given email
        await dynamoDB.delete(params).promise();

        return {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Methods": "DELETE, OPTIONS",
            },
            body: JSON.stringify({ message: "All job applications withdrawn successfully." }),
        };
    } catch (error) {
        console.error("Error withdrawing applications:", error);
        return {
            statusCode: 500,
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Methods": "DELETE, OPTIONS",
            },
            body: JSON.stringify({ message: "Failed to withdraw job applications." }),
        };
    }
};
