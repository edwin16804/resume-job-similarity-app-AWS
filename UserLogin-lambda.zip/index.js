const AWS = require('aws-sdk');
const dynamoDB = new AWS.DynamoDB.DocumentClient();

exports.handler = async (event) => {
    const headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': true, // Allow credentials
        'Content-Type': 'application/json', 
    };

    if (event.httpMethod === 'OPTIONS') {
        return {
            statusCode: 200,
            headers,
        };
    }

    try {
        const { email, password } = JSON.parse(event.body);

        const params = {
            TableName: 'JobAI_Users',
            IndexName: 'email-index',
            KeyConditionExpression: 'email = :email',
            ExpressionAttributeValues: {
                ':email': email,
            },
        };

        const data = await dynamoDB.query(params).promise();

        if (data.Items.length === 0) {
            return {
                statusCode: 401,
                headers,
                body: JSON.stringify({ message: 'User not found' }),
            };
        }

        const user = data.Items[0];
        if (user.passwd !== password) {
            return {
                statusCode: 401,
                headers,
                body: JSON.stringify({ message: 'Invalid credentials' }),
            };
        }

        return {
            statusCode: 200,
            headers,
            body: JSON.stringify({ 
                message: 'Login successful',
                user: {
                    name: user.username,
                    email: user.email,
                    
                }
            }),
        };
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({ message: 'Internal server error' }),
        };
    }
};
