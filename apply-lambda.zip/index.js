const AWS = require("aws-sdk");
const dynamoDB = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = "AppliedJobs"; // Replace with your DynamoDB table name

exports.handler = async (event) => {
    try {
        const { email, jobDescription } = JSON.parse(event.body);

        if (!email || !jobDescription) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: "Email and job description are required." }),
            };
        }

        const params = {
            TableName: TABLE_NAME,
            Item: {
                email, // Store email
                jobDescription, // Store job description
            },
        };

        await dynamoDB.put(params).promise();

        return {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Origin": "*", // Allow the specific origin
                "Access-Control-Allow-Headers": "Content-Type", // Allow necessary headers
                "Access-Control-Allow-Methods": "OPTIONS,POST", // Allow necessary methods
            },
            body: JSON.stringify({ message: "Job application saved successfully." }),
        };
        
    } catch (error) {
        console.error("Error saving job application:", error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: "Failed to save job application." }),
        };
    }
};
